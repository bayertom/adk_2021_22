#include "sortbyx.h"

sortByX::sortByX()
{

}
