#include "sortbyy.h"

sortByY::sortByY()
{

}
