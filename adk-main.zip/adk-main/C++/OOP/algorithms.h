#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <point.h>

class Algorithms
{
    public:
        Algorithms();
        double getDistance(Point &p1, Point &p2);
};

#endif // ALGORITHMS_H
