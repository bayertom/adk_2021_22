#include "point.h"

int Point::count = 0;
