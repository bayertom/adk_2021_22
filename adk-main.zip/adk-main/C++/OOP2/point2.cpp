#include "point2.h"

int Point2::count = 0;
